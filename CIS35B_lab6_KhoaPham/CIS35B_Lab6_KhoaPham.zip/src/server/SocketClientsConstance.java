package server;

/*
 *Name: Khoa Pham
 *Class: CIS35B
 *Assignment 5 ( Lab5)
 *Due: 6/12/2018
 *date submitted: 6/13/2018
 */
public interface SocketClientsConstance {
	int iECHO_PORT = 7;
	int iDAYTIME_PORT = 13;
	int iSMTP_PORT = 25;
	boolean DEBUG = true;
}
