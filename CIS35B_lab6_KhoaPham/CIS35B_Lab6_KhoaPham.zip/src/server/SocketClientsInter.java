package server;

/*
 *Name: Khoa Pham
 *Class: CIS35B
 *Assignment 5 ( Lab5)
 *Due: 6/12/2018
 *date submitted: 6/13/2018
 */
public interface SocketClientsInter {
	boolean openConnection();

	void handleSession();

	void closeSession();
}
