In lap 6, I find out that this lab is a new idea for me in learning CIS and I think it is not easy. I understand the structure of the lab but I can't make it 
work properly yet. I will try more on the summer to see how far can I go. I have learned a lot HTTP and servlet concepts at the final project and I like it. I thank for
a great quarter. 