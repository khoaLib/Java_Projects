package adapter;

/*
 *Name: Khoa Pham
 *Class: CIS35B
 *Assignment 4 ( Lab4)
 *Due: 5/29/2018
 *date submitted: 5/29/2018
 */
public interface UpdateAuto {
	public void UpdateOptionSetName(String newOpSetName, String oldOpSetName,String k);

	public void UpdateOptionPrice(String optionSetToSearch, String optionNameToSearching, float numb,String k);

}
