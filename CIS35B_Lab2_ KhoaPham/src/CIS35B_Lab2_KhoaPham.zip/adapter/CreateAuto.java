package adapter;
/*
 *Name: Khoa Pham
 *Class: CIS35B
 *Assignment 2 ( Lab2)
 *Due: 5/4/2018
 *date submitted: 5/4/2018
 */

public interface CreateAuto {
	public void BuildAuto(String fileName);

	public void printAuto(String modelName);
}
