package adapter;

public interface UpdateAuto {
	public void UpdateOptionSetName(String newOpSetName, String oldOpSetName);

	public void UpdateOptionPrice(String optionSetToSearch, String optionNameToSearching, float numb);

}
