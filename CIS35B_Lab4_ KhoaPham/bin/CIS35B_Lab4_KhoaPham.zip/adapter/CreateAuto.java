package adapter;
/*
 *Name: Khoa Pham
 *Class: CIS35B
 *Assignment 4 ( Lab4)
 *Due: 5/29/2018
 *date submitted: 5/29/2018
 */

public interface CreateAuto {
	public void BuildAuto(String fileName, String k);

	public void printAuto(String modelName, String k);
}
