package adapter;

import scale.Scalable;

/*
 *Name: Khoa Pham
 *Class: CIS35B
 *Assignment 4 ( Lab4)
 *Due: 5/29/2018
 *date submitted: 5/29/2018
 */

public class BuildAuto extends proxyAutomobile implements CreateAuto, UpdateAuto, FixAuto, Scalable {

}
