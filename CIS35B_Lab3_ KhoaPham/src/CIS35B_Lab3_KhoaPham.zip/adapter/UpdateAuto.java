package adapter;

/*
 *Name: Khoa Pham
 *Class: CIS35B
 *Assignment 3 ( Lab3)
 *Due: 5/15/2018
 *date submitted: 5/15/2018
 */
public interface UpdateAuto {
	public void UpdateOptionSetName(String newOpSetName, String oldOpSetName);

	public void UpdateOptionPrice(String optionSetToSearch, String optionNameToSearching, float numb);

}
