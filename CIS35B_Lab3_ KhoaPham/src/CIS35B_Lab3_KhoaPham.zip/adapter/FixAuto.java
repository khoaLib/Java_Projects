package adapter;
/*
 *Name: Khoa Pham
 *Class: CIS35B
 *Assignment 3 ( Lab3)
 *Due: 5/15/2018
 *date submitted: 5/15/2018
 */

public interface FixAuto {
	public void fix(int errorNo);

}
